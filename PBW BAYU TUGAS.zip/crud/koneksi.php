<?php

$db = mysqli_connect("localhost", "root", "", "perpustakaan_bayu") or die("gagal konek");
