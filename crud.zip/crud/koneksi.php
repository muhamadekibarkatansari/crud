<?php

$db = mysqli_connect("localhost", "root", "", "perpustakaan") or die("gagal konek");
